# Online Healthcare Management System (Java 21 + MySQL 8 + JDBC)

A beginner-friendly console project structured for practical evaluation. It uses plain JDBC; no ORM or web framework. **Important scope note:** this is a college demonstration baseline, not a production clinical system. Before real deployment add authentication/session management, role authorization at every service entry point, audit logging, encryption/key management, migrations, robust schedule/overlap logic, and privacy/compliance review.

## Requirements
- JDK 21
- Maven 3.9+
- MySQL 8.0+

## Setup
1. Create a local database user (avoid using root in normal development), then execute the schema:
   ```bash
   mysql -u root -p < src/main/resources/schema.sql
   ```
2. Configure environment variables (do not commit secrets):
   ```bash
   export DB_URL='jdbc:mysql://localhost:3306/healthcare_db?serverTimezone=UTC'
   export DB_USER='healthcare_app'
   export DB_PASSWORD='your-local-password'
   ```
   `DB_URL` defaults to localhost/healthcare_db. `DB_PASSWORD` defaults to blank only to make a fresh local MySQL setup easier; set it explicitly for your account.
3. Build and run:
   ```bash
   mvn clean package
   mvn exec:java
   ```
4. The seed records use `REPLACE_WITH_PBKDF2_HASH` placeholders and are **not usable login credentials**. The app's `PasswordUtil.hash(char[])` creates PBKDF2-HMAC-SHA256 hashes; use it when implementing registration/login. Never store plaintext passwords.

## Console options
- `1`: list users
- `2`: list doctors
- `3`: list appointments
- `4`: concurrent booking demonstration (uses seeded patient id 3 / doctor id 2 and requires DB availability)
- `0`: exit

## Evaluation map
| Requirement | Marks | Evidence |
|---|---:|---|
| OOP | 10 | `model/User.java`, `Admin.java`, `Doctor.java`, `Patient.java`; `interfaces/*`; `exceptions/*`; `main/Main.java` |
| Collections + Generics | 6 | `Main.java` (`List`, `Set`, `HashMap`); `dao/GenericDAO.java`; DAO implementations |
| Multithreading + synchronization | 4 | `threading/BookingTask.java`; `service/BookingService.java` synchronized method; `Main.runConcurrencyDemo()` |
| Database operation classes | 7 | `dao/UserDAO.java`, `DoctorDAO.java`, `AppointmentDAO.java`, `MedicalRecordDAO.java` |
| JDBC connection | 3 | `database/DBConnection.java` (`DriverManager`) |
| JDBC implementation | 3 | DAO classes use `Connection`, `PreparedStatement`, `ResultSet`, `executeQuery`, `executeUpdate`; schema persists data |

## OOP concepts, exact locations
- **Abstraction:** abstract `User` defines `getRole()` and `dashboardSummary()`.
- **Inheritance:** `Admin`, `Doctor`, and `Patient` extend `User`.
- **Encapsulation:** model state is private with public accessors/mutators; `Doctor.setSlotMinutes` validates input.
- **Runtime polymorphism:** `Main.main` stores all roles as `List<User>` and invokes overridden `dashboardSummary()`.
- **Interfaces:** `AppointmentOperations` and `UserOperations` define service contracts; `BookingService` and `UserService` implement them. `GenericDAO<T, ID>` is a generic DAO contract.
- **Custom exceptions:** `AppointmentConflictException` and `InvalidUserException` represent domain errors.
- **Exception/resource handling:** JDBC resources use try-with-resources. Console uses `try/catch/finally`; booking rolls back transaction on failure.

## Collections and generics
`Main.java` uses `ArrayList`/`List` for a queue, `HashSet`/`Set` to deduplicate emails, and `HashMap<Long, User>` for lookup. `GenericDAO<T, ID>` and entity-specific implementations enforce compile-time type safety. These in-memory collections are examples/caches only; MySQL is persistent storage.

## Concurrency and booking safety
`BookingTask` is a `Runnable`, executed via `ExecutorService`; a `CountDownLatch` releases contenders together. `BookingService.book` is synchronized within a single JVM and performs a transaction. The unique key `UNIQUE(doctor_id, starts_at)` is the cross-instance final guard for exact start-time duplicates. **A production implementation should also prevent overlapping intervals**, use consistent locking/isolation and retry handling, and exclude cancelled slots from the uniqueness design (e.g., a separate active-slot table or generated nullable key). The current unique key also reserves a cancelled appointment's slot unless the record is removed, so cancellation/rescheduling policy should be upgraded before real use.

## JDBC and CRUD
- Create: `create(...)` methods in each DAO.
- Read: `findById`, `findAll`, plus scoped methods.
- Update: `UserDAO.updateContact`, `DoctorDAO.updateAvailability`, `AppointmentDAO.setStatus`, `MedicalRecordDAO.updateNotes`.
- Delete: `delete(...)` in each DAO.
- Parameterized statements are used throughout. Try-with-resources closes JDBC resources. Data stored in MySQL remains after process restart.

## Authorization/security note
Scoped DAO methods (`findForPatient`, `findForDoctor`, status updates constrained by patient id) show ownership-aware SQL patterns. This demo does not implement a secure login/session layer and its console demo includes an admin-style listing. Do not expose these operations to untrusted users until a verified identity/role is passed through every service call and authorization is enforced centrally. Medical record access should require an active treating relationship and auditing.

## Test plan and expected behavior
1. **Connection test:** run `mvn exec:java`; with correct credentials it prints `JDBC connected: MySQL / healthcare_db` and the number of persisted users. Without a running/configured DB it prints a JDBC connection error.
2. **Polymorphism/collections:** startup prints three different role dashboard summaries and `unique emails=2`.
3. **DAO CRUD:** create a fictional user through `UserDAO.create`, fetch by ID/email, call `updateContact`, then `delete`; each returns a generated ID / optional / boolean.
4. **Persistence:** add a record, exit, restart, and select it again; it remains because it is stored in MySQL.
5. **Concurrency:** with DB setup and seed profiles, choose `4`. For five attempts to the same doctor/start, at most one should print `SUCCESS`; the rest should be rejected or report a DB conflict. A DB failure can cause all attempts to fail.
6. **Availability:** a slot outside `doctor_profiles.available_from`/`available_to` should be rejected.

## Known next improvements
- Add proper reschedule operation and role-specific menus, password verification, and authorization service.
- Validate that the patient/doctor IDs are active and that the selected time matches the doctor's slot grid.
- Enforce all interval overlaps, timezone policy, transaction retries, and cancellation slot reuse.
- Add JUnit integration tests against a disposable MySQL instance. Automated DB tests have not been run as part of this package build.

## Viva questions and answers
1. **Why is `User` abstract?** All user types share identity fields but must supply role-specific behavior.
2. **What is runtime polymorphism here?** `User` references call overridden `dashboardSummary()` implementations.
3. **Why encapsulation?** Private fields protect state and setters can validate values.
4. **Why interfaces?** Services depend on stable contracts instead of concrete behavior.
5. **Why use `PreparedStatement`?** It binds values safely and helps prevent SQL injection.
6. **`executeQuery` vs `executeUpdate`?** The former returns rows for queries; the latter reports affected rows for insert/update/delete.
7. **Why try-with-resources?** JDBC resources are closed even when exceptions occur.
8. **What is a race condition?** Multiple threads can check the same slot before either writes; synchronized booking serializes threads inside one JVM.
9. **Why also use a database constraint?** Synchronization cannot coordinate separate JVMs or server instances.
10. **What is a generic DAO?** A reusable CRUD contract parameterized by entity and ID types.
11. **Why not store passwords as text?** A database leak would expose them; store salted, slow password hashes instead.
12. **Why are collections not the database?** They are temporary process memory and disappear on exit; MySQL persists records.
