package com.healthcare.threading;
import com.healthcare.exceptions.AppointmentConflictException; import com.healthcare.model.Appointment; import com.healthcare.service.BookingService; import java.time.LocalDateTime; import java.util.concurrent.CountDownLatch;
/** Runnable used by the concurrency demo. */
public class BookingTask implements Runnable {
 private final BookingService service;private final long patientId,doctorId;private final LocalDateTime start;private final CountDownLatch gate;
 public BookingTask(BookingService s,long p,long d,LocalDateTime t,CountDownLatch g){service=s;patientId=p;doctorId=d;start=t;gate=g;}
 @Override public void run(){try{gate.await();Appointment a=service.book(patientId,doctorId,start,"Concurrency demonstration");System.out.println(Thread.currentThread().getName()+" SUCCESS appointment="+a.getId());}catch(AppointmentConflictException e){System.out.println(Thread.currentThread().getName()+" REJECTED: "+e.getMessage());}catch(InterruptedException e){Thread.currentThread().interrupt();}catch(RuntimeException e){System.out.println(Thread.currentThread().getName()+" ERROR: "+e.getMessage());}}
}
