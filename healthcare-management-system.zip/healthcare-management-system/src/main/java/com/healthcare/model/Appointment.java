package com.healthcare.model;
import java.time.LocalDateTime;
public class Appointment {
 public enum Status { BOOKED, CONFIRMED, COMPLETED, CANCELLED }
 private long id,patientId,doctorId; private LocalDateTime startsAt,endsAt; private Status status; private String reason;
 public Appointment(long id,long patientId,long doctorId,LocalDateTime startsAt,LocalDateTime endsAt,Status status,String reason){this.id=id;this.patientId=patientId;this.doctorId=doctorId;this.startsAt=startsAt;this.endsAt=endsAt;this.status=status;this.reason=reason;}
 public long getId(){return id;} public void setId(long v){id=v;} public long getPatientId(){return patientId;} public long getDoctorId(){return doctorId;}
 public LocalDateTime getStartsAt(){return startsAt;} public LocalDateTime getEndsAt(){return endsAt;} public Status getStatus(){return status;} public void setStatus(Status v){status=v;} public String getReason(){return reason;}
}
