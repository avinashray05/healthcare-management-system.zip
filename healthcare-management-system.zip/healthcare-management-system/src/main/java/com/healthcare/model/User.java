package com.healthcare.model;

public abstract class User {
    private long id;
    private String fullName;
    private String email;
    private String passwordHash;
    private boolean active;
    protected User(long id, String fullName, String email, String passwordHash, boolean active) {
        this.id=id; this.fullName=fullName; this.email=email; this.passwordHash=passwordHash; this.active=active;
    }
    public abstract String getRole();
    public abstract String dashboardSummary();
    public long getId(){return id;} public void setId(long id){this.id=id;}
    public String getFullName(){return fullName;} public void setFullName(String v){fullName=v;}
    public String getEmail(){return email;} public void setEmail(String v){email=v;}
    public String getPasswordHash(){return passwordHash;} public void setPasswordHash(String v){passwordHash=v;}
    public boolean isActive(){return active;} public void setActive(boolean v){active=v;}
}
