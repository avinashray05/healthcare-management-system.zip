package com.healthcare.model;
public class Doctor extends User {
 private String specialization; private int slotMinutes;
 public Doctor(long id,String name,String email,String hash,boolean active,String specialization,int slotMinutes){super(id,name,email,hash,active);this.specialization=specialization;this.slotMinutes=slotMinutes;}
 @Override public String getRole(){return "DOCTOR";}
 @Override public String dashboardSummary(){return "Doctor dashboard: appointments, availability and authorized patient records.";}
 public String getSpecialization(){return specialization;} public void setSpecialization(String v){specialization=v;}
 public int getSlotMinutes(){return slotMinutes;} public void setSlotMinutes(int v){if(v<10||v>240)throw new IllegalArgumentException("Slot length must be 10-240 minutes");slotMinutes=v;}
}
