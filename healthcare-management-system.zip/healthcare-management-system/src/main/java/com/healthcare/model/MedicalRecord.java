package com.healthcare.model;
import java.time.LocalDateTime;
public class MedicalRecord {
 private long id,patientId,doctorId; private Long appointmentId; private String diagnosis,treatment,notes; private LocalDateTime createdAt;
 public MedicalRecord(long id,long patientId,long doctorId,Long appointmentId,String diagnosis,String treatment,String notes,LocalDateTime createdAt){this.id=id;this.patientId=patientId;this.doctorId=doctorId;this.appointmentId=appointmentId;this.diagnosis=diagnosis;this.treatment=treatment;this.notes=notes;this.createdAt=createdAt;}
 public long getId(){return id;} public long getPatientId(){return patientId;} public long getDoctorId(){return doctorId;} public Long getAppointmentId(){return appointmentId;} public String getDiagnosis(){return diagnosis;} public String getTreatment(){return treatment;} public String getNotes(){return notes;} public LocalDateTime getCreatedAt(){return createdAt;}
}
