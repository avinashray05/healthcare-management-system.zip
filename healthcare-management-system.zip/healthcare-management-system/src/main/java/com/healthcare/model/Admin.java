package com.healthcare.model;
public class Admin extends User {
 public Admin(long id,String name,String email,String hash,boolean active){super(id,name,email,hash,active);}
 @Override public String getRole(){return "ADMIN";}
 @Override public String dashboardSummary(){return "Admin dashboard: manage users, doctors, patients, appointments and settings.";}
}
