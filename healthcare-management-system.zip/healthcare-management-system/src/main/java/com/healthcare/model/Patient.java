package com.healthcare.model;
public class Patient extends User {
 private String bloodGroup; private String address;
 public Patient(long id,String name,String email,String hash,boolean active,String bloodGroup,String address){super(id,name,email,hash,active);this.bloodGroup=bloodGroup;this.address=address;}
 @Override public String getRole(){return "PATIENT";}
 @Override public String dashboardSummary(){return "Patient dashboard: book, view, cancel appointments and review personal history.";}
 public String getBloodGroup(){return bloodGroup;} public void setBloodGroup(String v){bloodGroup=v;}
 public String getAddress(){return address;} public void setAddress(String v){address=v;}
}
