package com.healthcare.exceptions;
public class AppointmentConflictException extends Exception { public AppointmentConflictException(String message){super(message);} }
