package com.healthcare.main;
import com.healthcare.dao.*;import com.healthcare.database.DBConnection;import com.healthcare.model.*;import com.healthcare.service.*;import com.healthcare.threading.BookingTask;
import java.sql.*;import java.time.*;import java.util.*;import java.util.concurrent.*;
public class Main {
 public static void main(String[] args){System.out.println("=== Online Healthcare Management System ===");
  // Polymorphism: one base-class reference invokes each overridden dashboard method.
  List<User> demoUsers=List.of(new Admin(1,"Demo Admin","admin@example.test","hash",true),new Doctor(2,"Dr Mira","mira@example.test","hash",true,"General Medicine",30),new Patient(3,"Riya Demo","riya@example.test","hash",true,"O+","Jaipur"));
  for(User u:demoUsers)System.out.println(u.getRole()+" -> "+u.dashboardSummary());
  // Collections demo: List, Set uniqueness, and HashMap lookup; DB remains permanent storage.
  List<String> queue=new ArrayList<>(List.of("appointment-101","appointment-102"));Set<String> uniqueEmails=new HashSet<>(List.of("riya@example.test","riya@example.test","mira@example.test"));Map<Long,User> usersById=new HashMap<>();demoUsers.forEach(u->usersById.put(u.getId(),u));
  System.out.println("Collection demo: appointments="+queue.size()+", unique emails="+uniqueEmails.size()+", user #2="+usersById.get(2L).getFullName());
  try(Connection c=DBConnection.getConnection()){System.out.println("JDBC connected: "+c.getMetaData().getDatabaseProductName()+" / "+c.getCatalog());
   System.out.println("Users persisted in MySQL: "+new UserDAO().findAll().size());
  }catch(SQLException e){System.err.println("JDBC connection failed: "+e.getMessage());System.err.println("Set DB_URL, DB_USER and DB_PASSWORD and run src/main/resources/schema.sql.");}
  System.out.println("\nMenu: 1=list users  2=list doctors  3=list appointments  4=concurrency booking demo  0=exit");
  try(Scanner in=new Scanner(System.in)){boolean running=true;while(running){System.out.print("Choice: ");if(!in.hasNextLine())break;String choice=in.nextLine().trim();try{switch(choice){case "1"->new UserDAO().findAll().forEach(u->System.out.println(u.getId()+" | "+u.getFullName()+" | "+u.getRole()+" | "+u.getEmail()));case "2"->new DoctorDAO().findAll().forEach(System.out::println);case "3"->new AppointmentDAO().findAll().forEach(a->System.out.println(a.getId()+" | patient="+a.getPatientId()+" doctor="+a.getDoctorId()+" "+a.getStartsAt()+" "+a.getStatus()));case "4"->runConcurrencyDemo();case "0"->running=false;default->System.out.println("Choose 0-4");}}catch(Exception e){System.err.println("Operation failed: "+e.getMessage());}}}catch(Exception e){System.err.println("Console error: "+e.getMessage());}finally{System.out.println("Healthcare system closed.");}
 }
 private static void runConcurrencyDemo()throws InterruptedException {System.out.println("Attempting concurrent booking. Requires valid patient/doctor seed records and DB connection.");LocalDateTime start=LocalDate.now().plusDays(2).atTime(10,0);BookingService service=new BookingService(new AppointmentDAO(),new DoctorDAO());int contenders=5;CountDownLatch gate=new CountDownLatch(1);ExecutorService pool=Executors.newFixedThreadPool(contenders);for(int i=0;i<contenders;i++)pool.submit(new BookingTask(service,3,2,start,gate));gate.countDown();pool.shutdown();if(!pool.awaitTermination(20,TimeUnit.SECONDS))pool.shutdownNow();System.out.println("Concurrency demo complete; database unique key doctor_id + starts_at is final cross-instance guard.");}
}
