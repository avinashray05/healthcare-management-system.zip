package com.healthcare.database;
import java.sql.Connection; import java.sql.DriverManager; import java.sql.SQLException;
/** JDBC connection factory. Set DB_URL, DB_USER and DB_PASSWORD in the environment. */
public final class DBConnection {
 private DBConnection(){}
 public static Connection getConnection() throws SQLException {
  String url=System.getenv().getOrDefault("DB_URL","jdbc:mysql://localhost:3306/healthcare_db?useSSL=false&serverTimezone=UTC");
  String user=System.getenv().getOrDefault("DB_USER","root"); String password=System.getenv("DB_PASSWORD");
  if(password==null) password=""; // Local development only; configure a non-empty secret outside source control.
  return DriverManager.getConnection(url,user,password);
 }
}
