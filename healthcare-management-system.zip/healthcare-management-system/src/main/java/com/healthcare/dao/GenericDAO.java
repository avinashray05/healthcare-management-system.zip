package com.healthcare.dao;
import java.sql.SQLException; import java.util.List; import java.util.Optional;
/** Generic, type-safe CRUD contract shared by entity-specific DAOs. */
public interface GenericDAO<T, ID> { ID create(T entity) throws SQLException; Optional<T> findById(ID id) throws SQLException; List<T> findAll() throws SQLException; boolean delete(ID id) throws SQLException; }
