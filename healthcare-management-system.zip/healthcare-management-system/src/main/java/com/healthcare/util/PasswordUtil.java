package com.healthcare.util;
import javax.crypto.SecretKeyFactory; import javax.crypto.spec.PBEKeySpec; import java.security.*; import java.util.Base64;
/** PBKDF2 password hashing; never store raw passwords. */
public final class PasswordUtil {private PasswordUtil(){} public static String hash(char[] password)throws GeneralSecurityException{byte[] salt=new byte[16];SecureRandom.getInstanceStrong().nextBytes(salt);PBEKeySpec spec=new PBEKeySpec(password,salt,210000,256);byte[] key=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();spec.clearPassword();return "pbkdf2-sha256$210000$"+Base64.getEncoder().encodeToString(salt)+"$"+Base64.getEncoder().encodeToString(key);} }
