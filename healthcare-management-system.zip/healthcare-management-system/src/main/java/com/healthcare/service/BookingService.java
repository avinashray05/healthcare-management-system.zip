package com.healthcare.service;
import com.healthcare.dao.*; import com.healthcare.database.DBConnection; import com.healthcare.exceptions.AppointmentConflictException; import com.healthcare.interfaces.AppointmentOperations; import com.healthcare.model.Appointment;
import java.sql.*; import java.time.*; import java.util.*;
/** Synchronization protects threads in this JVM; transaction + unique index protects other app instances. */
public class BookingService implements AppointmentOperations {
 private final AppointmentDAO dao; private final DoctorDAO doctors;
 public BookingService(AppointmentDAO dao,DoctorDAO doctors){this.dao=dao;this.doctors=doctors;}
 @Override public synchronized Appointment book(long patientId,long doctorId,LocalDateTime start,String reason)throws AppointmentConflictException {
  if(start==null||!start.isAfter(LocalDateTime.now()))throw new IllegalArgumentException("Appointment must be in the future");
  try(Connection c=DBConnection.getConnection()) {c.setAutoCommit(false);try {
   DoctorDAO check=new DoctorDAO(); LocalTime time=start.toLocalTime();
   if(!check.isAvailable(doctorId,Time.valueOf(time),Time.valueOf(time.plusMinutes(30))))throw new AppointmentConflictException("Doctor is unavailable at that time");
   LocalDateTime end=start.plusMinutes(30);
   try(PreparedStatement p=c.prepareStatement("SELECT id FROM appointments WHERE doctor_id=? AND starts_at=? AND status<>'CANCELLED' FOR UPDATE")){p.setLong(1,doctorId);p.setTimestamp(2,Timestamp.valueOf(start));try(ResultSet r=p.executeQuery()){if(r.next())throw new AppointmentConflictException("This doctor slot is already booked");}}
   try(PreparedStatement p=c.prepareStatement("INSERT INTO appointments(patient_id,doctor_id,starts_at,ends_at,status,reason) VALUES(?,?,?,?, 'BOOKED',?)",Statement.RETURN_GENERATED_KEYS)){p.setLong(1,patientId);p.setLong(2,doctorId);p.setTimestamp(3,Timestamp.valueOf(start));p.setTimestamp(4,Timestamp.valueOf(end));p.setString(5,reason);p.executeUpdate();try(ResultSet r=p.getGeneratedKeys()){r.next();long id=r.getLong(1);c.commit();return new Appointment(id,patientId,doctorId,start,end,Appointment.Status.BOOKED,reason);}}
  }catch(Exception e){c.rollback();if(e instanceof AppointmentConflictException ace)throw ace;if(e instanceof SQLIntegrityConstraintViolationException)throw new AppointmentConflictException("Slot already booked (database constraint)");if(e instanceof SQLException se)throw new IllegalStateException("Booking failed: "+se.getMessage(),se);throw new IllegalStateException(e);}
  }catch(SQLException e){throw new IllegalStateException("Database unavailable: "+e.getMessage(),e);}
 }
 @Override public boolean cancel(long appointmentId,long patientId){try{return dao.setStatus(appointmentId,patientId,Appointment.Status.CANCELLED);}catch(SQLException e){throw new IllegalStateException("Unable to cancel appointment",e);}}
}
