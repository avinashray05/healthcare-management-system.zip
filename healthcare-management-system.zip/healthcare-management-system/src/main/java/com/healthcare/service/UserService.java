package com.healthcare.service;
import com.healthcare.dao.UserDAO; import com.healthcare.exceptions.InvalidUserException; import com.healthcare.interfaces.UserOperations; import com.healthcare.model.User; import java.sql.SQLException; import java.util.*;
public class UserService implements UserOperations {
 private final UserDAO dao; private final Map<String,User> emailCache=new HashMap<>();
 public UserService(UserDAO dao){this.dao=dao;}
 @Override public User register(User u)throws InvalidUserException{if(u==null||u.getFullName()==null||u.getFullName().isBlank()||u.getEmail()==null||!u.getEmail().contains("@")||u.getPasswordHash()==null||!u.getPasswordHash().startsWith("pbkdf2-sha256$"))throw new InvalidUserException("Name, valid email and hashed password are required");try{u.setId(dao.create(u));emailCache.put(u.getEmail().toLowerCase(Locale.ROOT),u);return u;}catch(SQLException e){throw new InvalidUserException("Could not register user: "+e.getMessage());}}
 @Override public User findByEmail(String email){if(email==null)return null;String key=email.toLowerCase(Locale.ROOT);if(emailCache.containsKey(key))return emailCache.get(key);try{User u=dao.findByEmail(email).orElse(null);if(u!=null)emailCache.put(key,u);return u;}catch(SQLException e){throw new IllegalStateException("Lookup failed",e);}}
}
