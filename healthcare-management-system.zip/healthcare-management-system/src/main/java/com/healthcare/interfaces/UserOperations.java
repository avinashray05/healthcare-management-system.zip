package com.healthcare.interfaces;
import com.healthcare.model.User;
import com.healthcare.exceptions.InvalidUserException;
public interface UserOperations { User register(User user) throws InvalidUserException; User findByEmail(String email); }
