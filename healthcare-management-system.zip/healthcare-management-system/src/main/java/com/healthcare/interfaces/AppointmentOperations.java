package com.healthcare.interfaces;
import com.healthcare.model.Appointment;
import com.healthcare.exceptions.AppointmentConflictException;
import java.time.LocalDateTime;
public interface AppointmentOperations { Appointment book(long patientId,long doctorId,LocalDateTime start,String reason) throws AppointmentConflictException; boolean cancel(long appointmentId,long patientId); }
